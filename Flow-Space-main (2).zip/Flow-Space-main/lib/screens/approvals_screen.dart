import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/approval_request.dart';

class ApprovalsScreen extends ConsumerStatefulWidget {
  const ApprovalsScreen({super.key});

  @override
  ConsumerState<ApprovalsScreen> createState() => _ApprovalsScreenState();
}

class _ApprovalsScreenState extends ConsumerState<ApprovalsScreen> {
  final List<ApprovalRequest> _approvalRequests = [
    ApprovalRequest(
      id: '1',
      itemName: 'User Authentication System',
      requester: 'John Doe',
      date: DateTime.now().subtract(const Duration(days: 2)),
      status: ApprovalStatus.pending,
      description: 'Complete user login and registration system with role-based access control',
    ),
    ApprovalRequest(
      id: '2',
      itemName: 'Payment Integration',
      requester: 'Jane Smith',
      date: DateTime.now().subtract(const Duration(days: 1)),
      status: ApprovalStatus.pending,
      description: 'Stripe payment gateway integration with subscription management',
    ),
    ApprovalRequest(
      id: '3',
      itemName: 'Mobile App Release',
      requester: 'Mike Johnson',
      date: DateTime.now().subtract(const Duration(days: 3)),
      status: ApprovalStatus.approved,
      description: 'iOS and Android app store deployment',
    ),
    ApprovalRequest(
      id: '4',
      itemName: 'Database Migration',
      requester: 'Sarah Wilson',
      date: DateTime.now().subtract(const Duration(days: 5)),
      status: ApprovalStatus.denied,
      description: 'Migration from MySQL to PostgreSQL',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Approvals'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilterDialog(),
            tooltip: 'Filter',
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => _refreshApprovals(),
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Column(
        children: [
          // Stats Cards
          _buildStatsSection(),
          
          // Approvals List
          Expanded(
            child: _approvalRequests.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _approvalRequests.length,
                    itemBuilder: (context, index) {
                      final request = _approvalRequests[index];
                      return _buildApprovalCard(request);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsSection() {
    final pendingCount = _approvalRequests.where((r) => r.status == ApprovalStatus.pending).length;
    final approvedCount = _approvalRequests.where((r) => r.status == ApprovalStatus.approved).length;
    final deniedCount = _approvalRequests.where((r) => r.status == ApprovalStatus.denied).length;

    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'Pending',
              pendingCount.toString(),
              Colors.orange,
              Icons.pending_actions,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Approved',
              approvedCount.toString(),
              Colors.green,
              Icons.check_circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Denied',
              deniedCount.toString(),
              Colors.red,
              Icons.cancel,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.approval,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No Approval Requests',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'When approval requests are created, they will appear here',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildApprovalCard(ApprovalRequest request) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        request.itemName,
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        request.description,
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                _buildStatusChip(request.status),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(
                  Icons.person,
                  size: 16,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 4),
                Text(
                  'Requested by ${request.requester}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey[600],
                  ),
                ),
                const Spacer(),
                Icon(
                  Icons.access_time,
                  size: 16,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 4),
                Text(
                  _formatDate(request.date),
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
            if (request.status == ApprovalStatus.pending) ...[
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _handleApproval(request.id, ApprovalStatus.denied),
                      icon: const Icon(Icons.close, color: Colors.red),
                      label: const Text('Deny', style: TextStyle(color: Colors.red)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Colors.red),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _handleApproval(request.id, ApprovalStatus.approved),
                      icon: const Icon(Icons.check, color: Colors.white),
                      label: const Text('Approve', style: TextStyle(color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatusChip(ApprovalStatus status) {
    Color color;
    IconData icon;
    
    switch (status) {
      case ApprovalStatus.pending:
        color = Colors.orange;
        icon = Icons.pending;
        break;
      case ApprovalStatus.approved:
        color = Colors.green;
        icon = Icons.check_circle;
        break;
      case ApprovalStatus.denied:
        color = Colors.red;
        icon = Icons.cancel;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color),
          const SizedBox(width: 4),
          Text(
            status.name.toUpperCase(),
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  void _handleApproval(String requestId, ApprovalStatus newStatus) {
    setState(() {
      final index = _approvalRequests.indexWhere((r) => r.id == requestId);
      if (index != -1) {
        _approvalRequests[index] = _approvalRequests[index].copyWith(status: newStatus);
      }
    });

    final statusText = newStatus == ApprovalStatus.approved ? 'approved' : 'denied';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Request $statusText successfully'),
        backgroundColor: newStatus == ApprovalStatus.approved ? Colors.green : Colors.red,
      ),
    );
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Filter Approvals'),
        content: const Text('Filter options will be implemented in the next phase.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _refreshApprovals() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Refreshing approvals...'),
      ),
    );
  }
}
```

Now let me create the ApprovalRequest model:

```dart:lib/models/approval_request.dart
import 'package:flutter/material.dart';

enum ApprovalStatus {
  pending,
  approved,
  denied,
}

class ApprovalRequest {
  final String id;
  final String itemName;
  final String requester;
  final DateTime date;
  final ApprovalStatus status;
  final String description;

  const ApprovalRequest({
    required this.id,
    required this.itemName,
    required this.requester,
    required this.date,
    required this.status,
    required this.description,
  });

  ApprovalRequest copyWith({
    String? id,
    String? itemName,
    String? requester,
    DateTime? date,
    ApprovalStatus? status,
    String? description,
  }) {
    return ApprovalRequest(
      id: id ?? this.id,
      itemName: itemName ?? this.itemName,
      requester: requester ?? this.requester,
      date: date ?? this.date,
      status: status ?? this.status,
      description: description ?? this.description,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'itemName': itemName,
      'requester': requester,
      'date': date.toIso8601String(),
      'status': status.name,
      'description': description,
    };
  }

  factory ApprovalRequest.fromJson(Map<String, dynamic> json) {
    return ApprovalRequest(
      id: json['id'],
      itemName: json['itemName'],
      requester: json['requester'],
      date: DateTime.parse(json['date']),
      status: ApprovalStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => ApprovalStatus.pending,
      ),
      description: json['description'],
    );
  }
}
```

Now let me create the Repository screen:

```dart:lib/screens/repository_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/repository_file.dart';

class RepositoryScreen extends ConsumerStatefulWidget {
  const RepositoryScreen({super.key});

  @override
  ConsumerState<RepositoryScreen> createState() => _RepositoryScreenState();
}

class _RepositoryScreenState extends ConsumerState<RepositoryScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<RepositoryFile> _files = [];
  List<RepositoryFile> _filteredFiles = [];

  @override
  void initState() {
    super.initState();
    _initializeFiles();
    _searchController.addListener(_filterFiles);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _initializeFiles() {
    _files = [
      RepositoryFile(
        id: '1',
        name: 'user-authentication-system.pdf',
        fileType: 'PDF',
        uploadDate: DateTime.now().subtract(const Duration(days: 3)),
        uploadedBy: 'john.doe@company.com',
        size: '2.4 MB',
        description: 'Complete user authentication system documentation',
      ),
      RepositoryFile(
        id: '2',
        name: 'payment-integration-guide.docx',
        fileType: 'DOCX',
        uploadDate: DateTime.now().subtract(const Duration(days: 1)),
        uploadedBy: 'jane.smith@company.com',
        size: '1.8 MB',
        description: 'Stripe payment integration implementation guide',
      ),
      RepositoryFile(
        id: '3',
        name: 'mobile-app-designs.fig',
        fileType: 'FIG',
        uploadDate: DateTime.now().subtract(const Duration(hours: 5)),
        uploadedBy: 'mike.johnson@company.com',
        size: '5.2 MB',
        description: 'Mobile app UI/UX design files',
      ),
      RepositoryFile(
        id: '4',
        name: 'database-schema.sql',
        fileType: 'SQL',
        uploadDate: DateTime.now().subtract(const Duration(days: 7)),
        uploadedBy: 'sarah.wilson@company.com',
        size: '156 KB',
        description: 'Database schema and migration scripts',
      ),
      RepositoryFile(
        id: '5',
        name: 'api-documentation.json',
        fileType: 'JSON',
        uploadDate: DateTime.now().subtract(const Duration(days: 2)),
        uploadedBy: 'alex.brown@company.com',
        size: '892 KB',
        description: 'REST API documentation and examples',
      ),
    ];
    _filteredFiles = List.from(_files);
  }

  void _filterFiles() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredFiles = _files.where((file) {
        return file.name.toLowerCase().contains(query) ||
               file.description.toLowerCase().contains(query) ||
               file.fileType.toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Repository'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.upload_file),
            onPressed: _showUploadDialog,
            tooltip: 'Upload File',
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshFiles,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Container(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search files...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _filterFiles();
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ),
          
          // Stats
          _buildStatsSection(),
          
          // Files List
          Expanded(
            child: _filteredFiles.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _filteredFiles.length,
                    itemBuilder: (context, index) {
                      final file = _filteredFiles[index];
                      return _buildFileCard(file);
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showUploadDialog,
        icon: const Icon(Icons.upload),
        label: const Text('Upload'),
      ),
    );
  }

  Widget _buildStatsSection() {
    final totalFiles = _files.length;
    final totalSize = _calculateTotalSize();
    final recentUploads = _files.where((f) => 
      DateTime.now().difference(f.uploadDate).inDays <= 7
    ).length;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'Total Files',
              totalFiles.toString(),
              Colors.blue,
              Icons.folder,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Total Size',
              totalSize,
              Colors.green,
              Icons.storage,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'This Week',
              recentUploads.toString(),
              Colors.orange,
              Icons.schedule,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 4),
            Text(
              value,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.folder_open,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No Files Found',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _searchController.text.isEmpty
                ? 'Upload your first file to get started'
                : 'No files match your search criteria',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
          if (_searchController.text.isNotEmpty) ...[
            const SizedBox(height: 16),
            TextButton(
              onPressed: () {
                _searchController.clear();
                _filterFiles();
              },
              child: const Text('Clear Search'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildFileCard(RepositoryFile file) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: _buildFileIcon(file.fileType),
        title: Text(
          file.name,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(file.description),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.person,
                  size: 14,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    file.uploadedBy,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ),
                Icon(
                  Icons.access_time,
                  size: 14,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 4),
                Text(
                  _formatDate(file.uploadDate),
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    file.size,
                    style: TextStyle(
                      fontSize: 10,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (value) => _handleFileAction(value, file),
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'download',
              child: Row(
                children: [
                  Icon(Icons.download),
                  SizedBox(width: 8),
                  Text('Download'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'share',
              child: Row(
                children: [
                  Icon(Icons.share),
                  SizedBox(width: 8),
                  Text('Share'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'delete',
              child: Row(
                children: [
                  Icon(Icons.delete, color: Colors.red),
                  SizedBox(width: 8),
                  Text('Delete', style: TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ],
        ),
        onTap: () => _handleFileAction('download', file),
      ),
    );
  }

  Widget _buildFileIcon(String fileType) {
    IconData iconData;
    Color color;
    
    switch (fileType.toUpperCase()) {
      case 'PDF':
        iconData = Icons.picture_as_pdf;
        color = Colors.red;
        break;
      case 'DOCX':
      case 'DOC':
        iconData = Icons.description;
        color = Colors.blue;
        break;
      case 'FIG':
        iconData = Icons.design_services;
        color = Colors.purple;
        break;
      case 'SQL':
        iconData = Icons.storage;
        color = Colors.green;
        break;
      case 'JSON':
        iconData = Icons.code;
        color = Colors.orange;
        break;
      default:
        iconData = Icons.insert_drive_file;
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(iconData, color: color, size: 24),
    );
  }

  String _calculateTotalSize() {
    // This is a simplified calculation
    final totalMB = _files.fold<double>(0, (sum, file) {
      final sizeStr = file.size.replaceAll(' MB', '').replaceAll(' KB', '');
      final size = double.tryParse(sizeStr) ?? 0;
      return sum + (file.size.contains('KB') ? size / 1024 : size);
    });
    
    if (totalMB < 1) {
      return '${(totalMB * 1024).toStringAsFixed(0)} KB';
    } else {
      return '${totalMB.toStringAsFixed(1)} MB';
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  void _handleFileAction(String action, RepositoryFile file) {
    switch (action) {
      case 'download':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Downloading ${file.name}...'),
          ),
        );
        break;
      case 'share':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Sharing ${file.name}...'),
          ),
        );
        break;
      case 'delete':
        _showDeleteConfirmation(file);
        break;
    }
  }

  void _showDeleteConfirmation(RepositoryFile file) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete File'),
        content: Text('Are you sure you want to delete "${file.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _files.removeWhere((f) => f.id == file.id);
                _filterFiles();
              });
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${file.name} deleted'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showUploadDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Upload File'),
        content: const Text('File upload functionality will be implemented in the next phase.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _refreshFiles() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Refreshing repository...'),
      ),
    );
  }
}
```

Now let me create the RepositoryFile model:

```dart:lib/models/repository_file.dart
class RepositoryFile {
  final String id;
  final String name;
  final String fileType;
  final DateTime uploadDate;
  final String uploadedBy;
  final String size;
  final String description;

  const RepositoryFile({
    required this.id,
    required this.name,
    required this.fileType,
    required this.uploadDate,
    required this.uploadedBy,
    required this.size,
    required this.description,
  });

  RepositoryFile copyWith({
    String? id,
    String? name,
    String? fileType,
    DateTime? uploadDate,
    String? uploadedBy,
    String? size,
    String? description,
  }) {
    return RepositoryFile(
      id: id ?? this.id,
      name: name ?? this.name,
      fileType: fileType ?? this.fileType,
      uploadDate: uploadDate ?? this.uploadDate,
      uploadedBy: uploadedBy ?? this.uploadedBy,
      size: size ?? this.size,
      description: description ?? this.description,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'fileType': fileType,
      'uploadDate': uploadDate.toIso8601String(),
      'uploadedBy': uploadedBy,
      'size': size,
      'description': description,
    };
  }

  factory RepositoryFile.fromJson(Map<String, dynamic> json) {
    return RepositoryFile(
      id: json['id'],
      name: json['name'],
      fileType: json['fileType'],
      uploadDate: DateTime.parse(json['uploadDate']),
      uploadedBy: json['uploadedBy'],
      size: json['size'],
      description: json['description'],
    );
  }
}
```

Now let me create the Notifications screen:

```dart:lib/screens/notifications_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/notification_item.dart';

class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});

  @override
  ConsumerState<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  List<NotificationItem> _notifications = [];
  bool _showUnreadOnly = false;

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
  }

  void _initializeNotifications() {
    _notifications = [
      NotificationItem(
        id: '1',
        title: 'New Approval Request',
        description: 'John Doe has submitted a new approval request for "User Authentication System"',
        date: DateTime.now().subtract(const Duration(minutes: 30)),
        isRead: false,
        type: NotificationType.approval,
      ),
      NotificationItem(
        id: '2',
        title: 'Deliverable Approved',
        description: 'Your deliverable "Payment Integration" has been approved by the client',
        date: DateTime.now().subtract(const Duration(hours: 2)),
        isRead: false,
        type: NotificationType.deliverable,
      ),
      NotificationItem(
        id: '3',
        title: 'Sprint Deadline Reminder',
        description: 'Sprint 3 ends in 2 days. Please ensure all tasks are completed',
        date: DateTime.now().subtract(const Duration(hours: 5)),
        isRead: true,
        type: NotificationType.sprint,
      ),
      NotificationItem(
        id: '4',
        title: 'File Uploaded',
        description: 'Jane Smith uploaded a new file "api-documentation.json" to the repository',
        date: DateTime.now().subtract(const Duration(days: 1)),
        isRead: true,
        type: NotificationType.repository,
      ),
      NotificationItem(
        id: '5',
        title: 'System Maintenance',
        description: 'Scheduled maintenance will occur on Sunday from 2:00 AM to 4:00 AM',
        date: DateTime.now().subtract(const Duration(days: 2)),
        isRead: true,
        type: NotificationType.system,
      ),
      NotificationItem(
        id: '6',
        title: 'Team Update',
        description: 'Welcome Sarah Wilson to the development team!',
        date: DateTime.now().subtract(const Duration(days: 3)),
        isRead: true,
        type: NotificationType.team,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final filteredNotifications = _showUnreadOnly
        ? _notifications.where((n) => !n.isRead).toList()
        : _notifications;

    final unreadCount = _notifications.where((n) => !n.isRead).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(_showUnreadOnly ? Icons.mark_email_read : Icons.mark_email_unread),
            onPressed: _toggleUnreadFilter,
            tooltip: _showUnreadOnly ? 'Show All' : 'Show Unread Only',
          ),
          if (unreadCount > 0)
            IconButton(
              icon: const Icon(Icons.done_all),
              onPressed: _markAllAsRead,
              tooltip: 'Mark All as Read',
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshNotifications,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Column(
        children: [
          // Stats
          _buildStatsSection(),
          
          // Notifications List
          Expanded(
            child: filteredNotifications.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: filteredNotifications.length,
                    itemBuilder: (context, index) {
                      final notification = filteredNotifications[index];
                      return _buildNotificationCard(notification);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsSection() {
    final unreadCount = _notifications.where((n) => !n.isRead).length;
    final todayCount = _notifications.where((n) => 
      DateTime.now().difference(n.date).inDays == 0
    ).length;
    final thisWeekCount = _notifications.where((n) => 
      DateTime.now().difference(n.date).inDays <= 7
    ).length;

    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'Unread',
              unreadCount.toString(),
              Colors.red,
              Icons.mark_email_unread,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Today',
              todayCount.toString(),
              Colors.blue,
              Icons.today,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'This Week',
              thisWeekCount.toString(),
              Colors.green,
              Icons.date_range,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.notifications_none,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            _showUnreadOnly ? 'No Unread Notifications' : 'No Notifications',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _showUnreadOnly
                ? 'You\'re all caught up!'
                : 'When notifications are sent, they will appear here',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationCard(NotificationItem notification) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => _markAsRead(notification.id),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: notification.isRead
                ? null
                : Border.all(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                    width: 2,
                  ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildNotificationIcon(notification.type),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                notification.title,
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: notification.isRead
                                      ? FontWeight.normal
                                      : FontWeight.bold,
                                ),
                              ),
                            ),
                            if (!notification.isRead)
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primary,
                                  shape: BoxShape.circle,
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          notification.description,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(
                    Icons.access_time,
                    size: 14,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDate(notification.date),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                  const Spacer(),
                  if (!notification.isRead)
                    TextButton(
                      onPressed: () => _markAsRead(notification.id),
                      child: const Text('Mark as Read'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNotificationIcon(NotificationType type) {
    IconData iconData;
    Color color;
    
    switch (type) {
      case NotificationType.approval:
        iconData = Icons.approval;
        color = Colors.orange;
        break;
      case NotificationType.deliverable:
        iconData = Icons.assignment;
        color = Colors.green;
        break;
      case NotificationType.sprint:
        iconData = Icons.timeline;
        color = Colors.blue;
        break;
      case NotificationType.repository:
        iconData = Icons.folder;
        color = Colors.purple;
        break;
      case NotificationType.system:
        iconData = Icons.settings;
        color = Colors.grey;
        break;
      case NotificationType.team:
        iconData = Icons.people;
        color = Colors.teal;
        break;
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(iconData, color: color, size: 20),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  void _markAsRead(String notificationId) {
    setState(() {
      final index = _notifications.indexWhere((n) => n.id == notificationId);
      if (index != -1) {
        _notifications[index] = _notifications[index].copyWith(isRead: true);
      }
    });
  }

  void _markAllAsRead() {
    setState(() {
      _notifications = _notifications.map((n) => n.copyWith(isRead: true)).toList();
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('All notifications marked as read'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _toggleUnreadFilter() {
    setState(() {
      _showUnreadOnly = !_showUnreadOnly;
    });
  }

  void _refreshNotifications() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Refreshing notifications...'),
      ),
    );
  }
}
```

Now let me create the NotificationItem model:

```dart:lib/models/notification_item.dart
enum NotificationType {
  approval,
  deliverable,
  sprint,
  repository,
  system,
  team,
}

class NotificationItem {
  final String id;
  final String title;
  final String description;
  final DateTime date;
  final bool isRead;
  final NotificationType type;

  const NotificationItem({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.isRead,
    required this.type,
  });

  NotificationItem copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? date,
    bool? isRead,
    NotificationType? type,
  }) {
    return NotificationItem(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      date: date ?? this.date,
      isRead: isRead ?? this.isRead,
      type: type ?? this.type,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'date': date.toIso8601String(),
      'isRead': isRead,
      'type': type.name,
    };
  }

  factory NotificationItem.fromJson(Map<String, dynamic> json) {
    return NotificationItem(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      date: DateTime.parse(json['date']),
      isRead: json['isRead'],
      type: NotificationType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => NotificationType.system,
      ),
    );
  }
}
```

Now I need to create a collapsible sidebar navigation. Let me create a new main screen that includes the sidebar and update the routing:

```dart:lib/screens/main_navigation_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'dashboard_screen.dart';
import 'deliverable_setup_screen.dart';
import 'sprint_console_screen.dart';
import 'approvals_screen.dart';
import 'repository_screen.dart';
import 'notifications_screen.dart';

// Provider for sidebar state
final sidebarStateProvider = StateNotifierProvider<SidebarStateNotifier, bool>((ref) {
  return SidebarStateNotifier();
});

class SidebarStateNotifier extends StateNotifier<bool> {
  SidebarStateNotifier() : super(false); // false = expanded, true = collapsed

  void toggle() {
    state = !state;
  }
}

class MainNavigationScreen extends ConsumerStatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  ConsumerState<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends ConsumerState<MainNavigationScreen> {
  int _currentIndex = 0;
  
  final List<NavigationItem> _navigationItems = [
    NavigationItem(
      icon: Icons.dashboard,
      label: 'Dashboard',
      route: '/dashboard',
    ),
    NavigationItem(
      icon: Icons.assignment,
      label: 'Deliverables',
      route: '/deliverable-setup',
    ),
    NavigationItem(
      icon: Icons.timeline,
      label: 'Sprints',
      route: '/sprint-console',
    ),
    NavigationItem(
      icon: Icons.approval,
      label: 'Approvals',
      route: '/approvals',
    ),
    NavigationItem(
      icon: Icons.folder,
      label: 'Repository',
      route: '/repository',
    ),
    NavigationItem(
      icon: Icons.notifications,
      label: 'Notifications',
      route: '/notifications',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final isCollapsed = ref.watch(sidebarStateProvider);
    
    return Scaffold(
      body: Row(
        children: [
          // Sidebar
          AnimatedContainer(
            duration: const Duration(milliseconds
