import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/repository_file.dart';

class RepositoryScreen extends ConsumerStatefulWidget {
  const RepositoryScreen({super.key});

  @override
  ConsumerState<RepositoryScreen> createState() => _RepositoryScreenState();
}

class _RepositoryScreenState extends ConsumerState<RepositoryScreen> {
  final TextEditingController _searchController = TextEditingController();
  List<RepositoryFile> _files = [];
  List<RepositoryFile> _filteredFiles = [];

  @override
  void initState() {
    super.initState();
    _initializeFiles();
    _searchController.addListener(_filterFiles);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  void _initializeFiles() {
    _files = [
      RepositoryFile(
        id: '1',
        name: 'user-authentication-system.pdf',
        fileType: 'PDF',
        uploadDate: DateTime.now().subtract(const Duration(days: 3)),
        uploadedBy: 'john.doe@company.com',
        size: '2.4 MB',
        description: 'Complete user authentication system documentation',
      ),
      RepositoryFile(
        id: '2',
        name: 'payment-integration-guide.docx',
        fileType: 'DOCX',
        uploadDate: DateTime.now().subtract(const Duration(days: 1)),
        uploadedBy: 'jane.smith@company.com',
        size: '1.8 MB',
        description: 'Stripe payment integration implementation guide',
      ),
      RepositoryFile(
        id: '3',
        name: 'mobile-app-designs.fig',
        fileType: 'FIG',
        uploadDate: DateTime.now().subtract(const Duration(hours: 5)),
        uploadedBy: 'mike.johnson@company.com',
        size: '5.2 MB',
        description: 'Mobile app UI/UX design files',
      ),
      RepositoryFile(
        id: '4',
        name: 'database-schema.sql',
        fileType: 'SQL',
        uploadDate: DateTime.now().subtract(const Duration(days: 7)),
        uploadedBy: 'sarah.wilson@company.com',
        size: '156 KB',
        description: 'Database schema and migration scripts',
      ),
      RepositoryFile(
        id: '5',
        name: 'api-documentation.json',
        fileType: 'JSON',
        uploadDate: DateTime.now().subtract(const Duration(days: 2)),
        uploadedBy: 'alex.brown@company.com',
        size: '892 KB',
        description: 'REST API documentation and examples',
      ),
    ];
    _filteredFiles = List.from(_files);
  }

  void _filterFiles() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredFiles = _files.where((file) {
        return file.name.toLowerCase().contains(query) ||
               file.description.toLowerCase().contains(query) ||
               file.fileType.toLowerCase().contains(query);
      }).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Repository'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.upload_file),
            onPressed: _showUploadDialog,
            tooltip: 'Upload File',
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshFiles,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Container(
            padding: const EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search files...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchController.clear();
                          _filterFiles();
                        },
                      )
                    : null,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.grey[50],
              ),
            ),
          ),
          
          // Stats
          _buildStatsSection(),
          
          // Files List
          Expanded(
            child: _filteredFiles.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _filteredFiles.length,
                    itemBuilder: (context, index) {
                      final file = _filteredFiles[index];
                      return _buildFileCard(file);
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showUploadDialog,
        icon: const Icon(Icons.upload),
        label: const Text('Upload'),
      ),
    );
  }

  Widget _buildStatsSection() {
    final totalFiles = _files.length;
    final totalSize = _calculateTotalSize();
    final recentUploads = _files.where((f) => 
      DateTime.now().difference(f.uploadDate).inDays <= 7
    ).length;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'Total Files',
              totalFiles.toString(),
              Colors.blue,
              Icons.folder,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Total Size',
              totalSize,
              Colors.green,
              Icons.storage,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'This Week',
              recentUploads.toString(),
              Colors.orange,
              Icons.schedule,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 4),
            Text(
              value,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.folder_open,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No Files Found',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _searchController.text.isEmpty
                ? 'Upload your first file to get started'
                : 'No files match your search criteria',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
          if (_searchController.text.isNotEmpty) ...[
            const SizedBox(height: 16),
            TextButton(
              onPressed: () {
                _searchController.clear();
                _filterFiles();
              },
              child: const Text('Clear Search'),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildFileCard(RepositoryFile file) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: _buildFileIcon(file.fileType),
        title: Text(
          file.name,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(file.description),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.person,
                  size: 14,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    file.uploadedBy,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                ),
                Icon(
                  Icons.access_time,
                  size: 14,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 4),
                Text(
                  _formatDate(file.uploadDate),
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    file.size,
                    style: TextStyle(
                      fontSize: 10,
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (value) => _handleFileAction(value, file),
          itemBuilder: (context) => [
            const PopupMenuItem(
              value: 'download',
              child: Row(
                children: [
                  Icon(Icons.download),
                  SizedBox(width: 8),
                  Text('Download'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'share',
              child: Row(
                children: [
                  Icon(Icons.share),
                  SizedBox(width: 8),
                  Text('Share'),
                ],
              ),
            ),
            const PopupMenuItem(
              value: 'delete',
              child: Row(
                children: [
                  Icon(Icons.delete, color: Colors.red),
                  SizedBox(width: 8),
                  Text('Delete', style: TextStyle(color: Colors.red)),
                ],
              ),
            ),
          ],
        ),
        onTap: () => _handleFileAction('download', file),
      ),
    );
  }

  Widget _buildFileIcon(String fileType) {
    IconData iconData;
    Color color;
    
    switch (fileType.toUpperCase()) {
      case 'PDF':
        iconData = Icons.picture_as_pdf;
        color = Colors.red;
        break;
      case 'DOCX':
      case 'DOC':
        iconData = Icons.description;
        color = Colors.blue;
        break;
      case 'FIG':
        iconData = Icons.design_services;
        color = Colors.purple;
        break;
      case 'SQL':
        iconData = Icons.storage;
        color = Colors.green;
        break;
      case 'JSON':
        iconData = Icons.code;
        color = Colors.orange;
        break;
      default:
        iconData = Icons.insert_drive_file;
        color = Colors.grey;
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(iconData, color: color, size: 24),
    );
  }

  String _calculateTotalSize() {
    // This is a simplified calculation
    final totalMB = _files.fold<double>(0, (sum, file) {
      final sizeStr = file.size.replaceAll(' MB', '').replaceAll(' KB', '');
      final size = double.tryParse(sizeStr) ?? 0;
      return sum + (file.size.contains('KB') ? size / 1024 : size);
    });
    
    if (totalMB < 1) {
      return '${(totalMB * 1024).toStringAsFixed(0)} KB';
    } else {
      return '${totalMB.toStringAsFixed(1)} MB';
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  void _handleFileAction(String action, RepositoryFile file) {
    switch (action) {
      case 'download':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Downloading ${file.name}...'),
          ),
        );
        break;
      case 'share':
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Sharing ${file.name}...'),
          ),
        );
        break;
      case 'delete':
        _showDeleteConfirmation(file);
        break;
    }
  }

  void _showDeleteConfirmation(RepositoryFile file) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete File'),
        content: Text('Are you sure you want to delete "${file.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                _files.removeWhere((f) => f.id == file.id);
                _filterFiles();
              });
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${file.name} deleted'),
                  backgroundColor: Colors.red,
                ),
              );
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showUploadDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Upload File'),
        content: const Text('File upload functionality will be implemented in the next phase.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _refreshFiles() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Refreshing repository...'),
      ),
    );
  }
}
