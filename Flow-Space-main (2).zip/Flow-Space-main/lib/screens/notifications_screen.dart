import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/notification_item.dart';

class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});

  @override
  ConsumerState<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  List<NotificationItem> _notifications = [];
  bool _showUnreadOnly = false;

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
  }

  void _initializeNotifications() {
    _notifications = [
      NotificationItem(
        id: '1',
        title: 'New Approval Request',
        description: 'John Doe has submitted a new approval request for "User Authentication System"',
        date: DateTime.now().subtract(const Duration(minutes: 30)),
        isRead: false,
        type: NotificationType.approval,
      ),
      NotificationItem(
        id: '2',
        title: 'Deliverable Approved',
        description: 'Your deliverable "Payment Integration" has been approved by the client',
        date: DateTime.now().subtract(const Duration(hours: 2)),
        isRead: false,
        type: NotificationType.deliverable,
      ),
      NotificationItem(
        id: '3',
        title: 'Sprint Deadline Reminder',
        description: 'Sprint 3 ends in 2 days. Please ensure all tasks are completed',
        date: DateTime.now().subtract(const Duration(hours: 5)),
        isRead: true,
        type: NotificationType.sprint,
      ),
      NotificationItem(
        id: '4',
        title: 'File Uploaded',
        description: 'Jane Smith uploaded a new file "api-documentation.json" to the repository',
        date: DateTime.now().subtract(const Duration(days: 1)),
        isRead: true,
        type: NotificationType.repository,
      ),
      NotificationItem(
        id: '5',
        title: 'System Maintenance',
        description: 'Scheduled maintenance will occur on Sunday from 2:00 AM to 4:00 AM',
        date: DateTime.now().subtract(const Duration(days: 2)),
        isRead: true,
        type: NotificationType.system,
      ),
      NotificationItem(
        id: '6',
        title: 'Team Update',
        description: 'Welcome Sarah Wilson to the development team!',
        date: DateTime.now().subtract(const Duration(days: 3)),
        isRead: true,
        type: NotificationType.team,
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final filteredNotifications = _showUnreadOnly
        ? _notifications.where((n) => !n.isRead).toList()
        : _notifications;

    final unreadCount = _notifications.where((n) => !n.isRead).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(_showUnreadOnly ? Icons.mark_email_read : Icons.mark_email_unread),
            onPressed: _toggleUnreadFilter,
            tooltip: _showUnreadOnly ? 'Show All' : 'Show Unread Only',
          ),
          if (unreadCount > 0)
            IconButton(
              icon: const Icon(Icons.done_all),
              onPressed: _markAllAsRead,
              tooltip: 'Mark All as Read',
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshNotifications,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Column(
        children: [
          // Stats
          _buildStatsSection(),
          
          // Notifications List
          Expanded(
            child: filteredNotifications.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: filteredNotifications.length,
                    itemBuilder: (context, index) {
                      final notification = filteredNotifications[index];
                      return _buildNotificationCard(notification);
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsSection() {
    final unreadCount = _notifications.where((n) => !n.isRead).length;
    final todayCount = _notifications.where((n) => 
      DateTime.now().difference(n.date).inDays == 0
    ).length;
    final thisWeekCount = _notifications.where((n) => 
      DateTime.now().difference(n.date).inDays <= 7
    ).length;

    return Container(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: _buildStatCard(
              'Unread',
              unreadCount.toString(),
              Colors.red,
              Icons.mark_email_unread,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'Today',
              todayCount.toString(),
              Colors.blue,
              Icons.today,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _buildStatCard(
              'This Week',
              thisWeekCount.toString(),
              Colors.green,
              Icons.date_range,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: color,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.notifications_none,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            _showUnreadOnly ? 'No Unread Notifications' : 'No Notifications',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _showUnreadOnly
                ? 'You\'re all caught up!'
                : 'When notifications are sent, they will appear here',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationCard(NotificationItem notification) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => _markAsRead(notification.id),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: notification.isRead
                ? null
                : Border.all(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                    width: 2,
                  ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildNotificationIcon(notification.type),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                notification.title,
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                  fontWeight: notification.isRead
                                      ? FontWeight.normal
                                      : FontWeight.bold,
                                ),
                              ),
                            ),
                            if (!notification.isRead)
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).colorScheme.primary,
                                  shape: BoxShape.circle,
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          notification.description,
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(
                    Icons.access_time,
                    size: 14,
                    color: Colors.grey[600],
                  ),
                  const SizedBox(width: 4),
                  Text(
                    _formatDate(notification.date),
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey[600],
                    ),
                  ),
                  const Spacer(),
                  if (!notification.isRead)
                    TextButton(
                      onPressed: () => _markAsRead(notification.id),
                      child: const Text('Mark as Read'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNotificationIcon(NotificationType type) {
    IconData iconData;
    Color color;
    
    switch (type) {
      case NotificationType.approval:
        iconData = Icons.approval;
        color = Colors.orange;
        break;
      case NotificationType.deliverable:
        iconData = Icons.assignment;
        color = Colors.green;
        break;
      case NotificationType.sprint:
        iconData = Icons.timeline;
        color = Colors.blue;
        break;
      case NotificationType.repository:
        iconData = Icons.folder;
        color = Colors.purple;
        break;
      case NotificationType.system:
        iconData = Icons.settings;
        color = Colors.grey;
        break;
      case NotificationType.team:
        iconData = Icons.people;
        color = Colors.teal;
        break;
    }

    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Icon(iconData, color: color, size: 20),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);
    
    if (difference.inDays > 0) {
      return '${difference.inDays}d ago';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}h ago';
    } else {
      return '${difference.inMinutes}m ago';
    }
  }

  void _markAsRead(String notificationId) {
    setState(() {
      final index = _notifications.indexWhere((n) => n.id == notificationId);
      if (index != -1) {
        _notifications[index] = _notifications[index].copyWith(isRead: true);
      }
    });
  }

  void _markAllAsRead() {
    setState(() {
      _notifications = _notifications.map((n) => n.copyWith(isRead: true)).toList();
    });
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('All notifications marked as read'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _toggleUnreadFilter() {
    setState(() {
      _showUnreadOnly = !_showUnreadOnly;
    });
  }

  void _refreshNotifications() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Refreshing notifications...'),
      ),
    );
  }
}
```

Now let me create the NotificationItem model:

```dart:lib/models/notification_item.dart
enum NotificationType {
  approval,
  deliverable,
  sprint,
  repository,
  system,
  team,
}

class NotificationItem {
  final String id;
  final String title;
  final String description;
  final DateTime date;
  final bool isRead;
  final NotificationType type;

  const NotificationItem({
    required this.id,
    required this.title,
    required this.description,
    required this.date,
    required this.isRead,
    required this.type,
  });

  NotificationItem copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? date,
    bool? isRead,
    NotificationType? type,
  }) {
    return NotificationItem(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      date: date ?? this.date,
      isRead: isRead ?? this.isRead,
      type: type ?? this.type,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'date': date.toIso8601String(),
      'isRead': isRead,
      'type': type.name,
    };
  }

  factory NotificationItem.fromJson(Map<String, dynamic> json) {
    return NotificationItem(
      id: json['id'],
      title: json['title'],
      description: json['description'],
      date: DateTime.parse(json['date']),
      isRead: json['isRead'],
      type: NotificationType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => NotificationType.system,
      ),
    );
  }
}
```

Now I need to create a collapsible sidebar navigation. Let me create a new main screen that includes the sidebar and update the routing:

```dart:lib/screens/main_navigation_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'dashboard_screen.dart';
import 'deliverable_setup_screen.dart';
import 'sprint_console_screen.dart';
import 'approvals_screen.dart';
import 'repository_screen.dart';
import 'notifications_screen.dart';

// Provider for sidebar state
final sidebarStateProvider = StateNotifierProvider<SidebarStateNotifier, bool>((ref) {
  return SidebarStateNotifier();
});

class SidebarStateNotifier extends StateNotifier<bool> {
  SidebarStateNotifier() : super(false); // false = expanded, true = collapsed

  void toggle() {
    state = !state;
  }
}

class MainNavigationScreen extends ConsumerStatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  ConsumerState<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends ConsumerState<MainNavigationScreen> {
  int _currentIndex = 0;
  
  final List<NavigationItem> _navigationItems = [
    NavigationItem(
      icon: Icons.dashboard,
      label: 'Dashboard',
      route: '/dashboard',
    ),
    NavigationItem(
      icon: Icons.assignment,
      label: 'Deliverables',
      route: '/deliverable-setup',
    ),
    NavigationItem(
      icon: Icons.timeline,
      label: 'Sprints',
      route: '/sprint-console',
    ),
    NavigationItem(
      icon: Icons.approval,
      label: 'Approvals',
      route: '/approvals',
    ),
    NavigationItem(
      icon: Icons.folder,
      label: 'Repository',
      route: '/repository',
    ),
    NavigationItem(
      icon: Icons.notifications,
      label: 'Notifications',
      route: '/notifications',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final isCollapsed = ref.watch(sidebarStateProvider);
    
    return Scaffold(
      body: Row(
        children: [
          // Sidebar
          AnimatedContainer(
            duration: const Duration(milliseconds
