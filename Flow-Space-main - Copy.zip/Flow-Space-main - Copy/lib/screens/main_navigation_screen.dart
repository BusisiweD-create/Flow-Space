import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'dashboard_screen.dart';
import 'deliverable_setup_screen.dart';
import 'sprint_console_screen.dart';
import 'approvals_screen.dart';
import 'repository_screen.dart';
import 'notifications_screen.dart';

// Provider for sidebar state
final sidebarStateProvider = StateNotifierProvider<SidebarStateNotifier, bool>((ref) {
  return SidebarStateNotifier();
});

class SidebarStateNotifier extends StateNotifier<bool> {
  SidebarStateNotifier() : super(false); // false = expanded, true = collapsed

  void toggle() {
    state = !state;
  }
}

class MainNavigationScreen extends ConsumerStatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  ConsumerState<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends ConsumerState<MainNavigationScreen> {
  int _currentIndex = 0;
  
  final List<NavigationItem> _navigationItems = [
    NavigationItem(
      icon: Icons.dashboard,
      label: 'Dashboard',
      route: '/dashboard',
    ),
    NavigationItem(
      icon: Icons.assignment,
      label: 'Deliverables',
      route: '/deliverable-setup',
    ),
    NavigationItem(
      icon: Icons.timeline,
      label: 'Sprints',
      route: '/sprint-console',
    ),
    NavigationItem(
      icon: Icons.approval,
      label: 'Approvals',
      route: '/approvals',
    ),
    NavigationItem(
      icon: Icons.folder,
      label: 'Repository',
      route: '/repository',
    ),
    NavigationItem(
      icon: Icons.notifications,
      label: 'Notifications',
      route: '/notifications',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final isCollapsed = ref.watch(sidebarStateProvider);
    
    return Scaffold(
      body: Row(
        children: [
          // Sidebar
          AnimatedContainer(
            duration: const Duration(milliseconds
